<?php    
$pulse_dir = "pulsepro";
$pulse_pass = "demo";
$height = "110";
$width = "110";
$blog_url = "http://example.com/blog";
$per_page = "5";
$blog_comments = true;
$blog_capcha = false;
$questions["What color is the ocean?"] = "blue";
$questions["What is the year after this one?"] = "2015";
$questions["How many letters in the word MARKET?"] = "6";
$date_format = "M d, Y";
$email_contact = "you@example.com";
$pulse_lang = "english";
$custom_fieldname1 = "";
$custom_fieldname2 = "";
$formcap = "";
$startpage = "manage-blocks";
$pulse_serial = "";
?>